Naming convention:
The folder instances_X_Y contains random SAT instances with X variables and Y clauses. Each of these instances is named instance_X_Y_i, where 1 <= i <= 10.

Instances solutions:
For each instance instance_X_Y_i there is a file instance_X_Y_i.log
that describes the output of the solver, i.e. whether the instance is
SATISFIABLE or UNSATISFIABLE, and if it is SATISFIABLE then a model is
given. Of course, you might have a different correct model.
