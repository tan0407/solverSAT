#ifndef FILEREADER_H_
#define FILEREADER_H_

#include <fstream>
#include <string>
#include <vector>
using namespace std;


vector<vector<int> > fileToClause(char* filePath,vector<int>& nbVar);



#endif /* FILEREADER_H_ */
